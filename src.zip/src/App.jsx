import { createContext, useEffect, useState } from 'react'
import {BrowserRouter as Router, Routes, Route} from "react-router-dom"

import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Malik from './Components/Malik'
import Button from './Components/Button'
import Component1 from './Components/Component1'
import Component2 from './Components/Component2'
import Component3 from './Components/Component3'
import Component4 from './Components/Component4'

const BrandContext = createContext();
const App = () => {
  const brand = "Lexus"
  const [control, setControl] = useState(true)
  const [myText, setMyText] = useState("initial state")

  useEffect(()=>{
    setTimeout((e)=>{
      setControl(!control)
    }, 1000)
  }, [myText])
  return (
    <>
    
      {/* <p>{myText}</p>
      <button onClick={()=>setMyText("current state")}>update</button>
      <button onClick={()=>setMyText("current statesssss")}>update</button>
      {control && <div style={{width:"100px", height:"100px", backgroundColor:"red", borderRadius:"50%"}}></div>}
      <div>{1 + 1}</div>
      <button onClick={()=>setControl(!control)}>switch</button>
      <Malik brand={brand} color={"blue"}/>
      <Button nameOfButton={brand}/> */}
      {/* {
        <BrandContext.Provider value={control}>
            <Component1/>
        </BrandContext.Provider>
      } */}
      <Router>
        <Routes>
          <Route path="/page1" element={<Component1/>}/>
          <Route path="/page2" element={<Component2/>}/>
          <Route path="/page3" element={<Component3/>}/>
          <Route path="/page4" element={<Component4/>}/>

        </Routes>
      </Router>
    </>
  )
}

export default App
