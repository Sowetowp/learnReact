import React from 'react'
import Component4 from './Component4'

const Component3 = () => {

  return (
    <>
        <div>Component3</div>
        {/* <Component4 /> */}
        <a href="/page4">page4</a>
    </>
  )
}

export default Component3