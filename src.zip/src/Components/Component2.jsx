import React from 'react'
import Component3 from './Component3'

const Component2 = () => {

  return (
    <>
        <div>Component2</div>
        {/* <Component3/> */}
        <a href="/page3">page3</a>
    </>
  )
}

export default Component2