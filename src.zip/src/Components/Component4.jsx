// import React, { useContext, createContext, useRef, useEffect } from 'react'

// const Component4 = () => {
//   const myRef = useRef()
//   useEffect(()=>{
//     myRef.current.style.color = "red"
//   },[])
//   return (
//     <div ref={myRef}>uuuuuuu</div>
//   )
// }

// export default Component4


import React from 'react'

const Component4 = () => {
  console.log(first)
  return (
    <div>Component4</div>
  )
}

export default Component4