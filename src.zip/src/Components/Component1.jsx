import React from 'react'
import Component2 from './Component2'

const Component1 = () => {
  return (
    <>
        <div>Component1</div>
        {/* <Component2/> */}
        <a href="/page2">page2</a>
    </>
  )
}

export default Component1